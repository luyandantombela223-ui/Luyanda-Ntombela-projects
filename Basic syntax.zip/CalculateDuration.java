// A program to find the time Duration between given times.
// Luyanda Ntombela 
// NTMLUY004
// 03 August 2024 

import java.util.Scanner;

public class CalculateDuration {

   public static void main(String[] args) {
               
        System.out.println("Enter time A:");
        Scanner input  = new Scanner(System.in);
        String A = input.next();
        
        System.out.println("Enter time B:");
        String B = input.next();
   
       Time t1 = new Time(A);
       Time t2 = new Time(B);

       
       Duration duration = t2.subtract(t1);
       
       long min = duration.intValue("minutes");
       
       System.out.println("The time " + t2 +" occurs "+  min + " minutes after the time " + t1 +".");
      
    
       
   }

}

// public class CalculateDuration{
// 
//         public static void main(String[] args){
//         
//         System.out.println("Enter time A:");
//         Scanner input  = new Scanner(System.in);
//         String A = input.next();
//         
//         
//         System.out.println("Enter time B:");
//         String B = input.next();
//         
//         
//         }       
//  }


 