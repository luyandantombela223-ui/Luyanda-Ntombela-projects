// A program to find total amount.
// Luyanda Ntombela 
// NTMLUY004
// 03 August 2024 

import java.util.Scanner;

public class SumCosts {

   public static void main(String[] args) {
   
   Scanner input = new Scanner(System.in); 
   float total = 0;
   Currency rand = new Currency("R","ZAR",100);
   Money mon =  new Money("R0.00",rand);
   
      
   String Moneyy;
   
  
  
  while(true){
  System.out.println("Enter an amount or '[D]one' to print the sum and quit:");
  
  Moneyy =input.next();
  char q = Moneyy.charAt(0);
  String s = Character.toString(q);
   
  
  if (!"R".equalsIgnoreCase(s)){
       break;
  }
 
 Money mono = new Money(Moneyy, rand);
 mon = mon.add(mono);
        

 
         
      }
  System.out.println("Total: "   + mon);
  
 }
  }