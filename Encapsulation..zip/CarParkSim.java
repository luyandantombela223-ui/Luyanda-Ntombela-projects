// A class that will perfom input/outputs of displaying tariffs of the car in the park
// Luyanda Ntombela
// NTMLUY004
// 29 August 2025

import java.util.Scanner;

public class CarParkSim {
    
    private CarParkSim() {}
    
    public static void main(final String[] args) {
        final Scanner keyboard = new Scanner(System.in);
        final Clock clock = new Clock(new Time("00:00:00"));
        final Register register = new Register();
        
        //
        final Currency myCurrency = new Currency("R", "ZAR", 100);
        final TariffTable tariffTable = new TariffTable(10);
        
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 0), new Duration("minute", 30)), new Money(10*100, myCurrency));
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 30), new Duration("minute", 60)), new Money(15*100, myCurrency));
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 60), new Duration("minute", 180)), new Money(20*100, myCurrency));
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 180), new Duration("minute", 240)), new Money(30*100, myCurrency));
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 240), new Duration("minute", 300)), new Money(40*100, myCurrency));
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 300), new Duration("minute", 360)), new Money(50*100, myCurrency));
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 360), new Duration("minute", 480)), new Money(60*100, myCurrency));
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 480), new Duration("minute", 600)), new Money(70*100, myCurrency));
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 600), new Duration("minute", 720)), new Money(90*100, myCurrency));
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 720), new Duration("minute", 1440)), new Money(100*100, myCurrency));
        
        
        System.out.println("Car Park Simulator");
        System.out.printf("The current time is %s.\n", clock.examine());
        System.out.println("Commands: tariffs, advance {minutes}, arrive, depart, quit.");
        System.out.print(">");
        String input = keyboard.next().toLowerCase();
        while (!input.equals("quit")) {
            if (input.equals("advance")) {
                clock.advance(new Duration("minute", keyboard.nextInt()));  
                System.out.printf("The current time is %s.\n", clock.examine());
            }
            else if (input.equals("arrive")) {
                final Ticket ticket = new Ticket(clock.examine());
                register.add(ticket);
                System.out.printf("Ticket issued: %s.\n", ticket);
            }
            else if (input.equals("depart")) {
                final String ID = keyboard.next();
                if (!register.contains(ID)) {
                    System.out.println("Invalid ticket ID.");
                }
                else {
                    final Ticket ticket = register.retrieve(ID);
                    final Duration myDuration = ticket.age(clock.examine());
                    final Money parkingMoney = tariffTable.getTariff(myDuration);
                    
                    System.out.printf("Ticket details: %s.\n", ticket);
                    System.out.printf("Current time: %s.\n", clock.examine());
                    System.out.printf("Duration of stay: %s.\n", Duration.format(myDuration, "minute"));
                    
                    if (parkingMoney != null)
                    {
                     System.out.printf("Cost of stay : %s.\n", parkingMoney);
                    }
                    else
                    {
                     System.out.println("No tariff found.");
                    }
                }
            }
            
            else if (input.equals("tariffs"))
            {
               System.out.println(tariffTable);
            }
            else {
                System.out.println("That command is not recognised.");
                System.out.println("Commands: tariffs, advance <minutes>, arrive, depart, quit.");
            }            
            System.out.print(">");
            input = keyboard.next().toLowerCase();
        }            
        System.out.println("Goodbye.");
    }

}
