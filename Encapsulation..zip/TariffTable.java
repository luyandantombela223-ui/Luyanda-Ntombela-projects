/**
 * TariffTable stores a sequence of ParkingTariff objects.
 * Each tariff consists of a TimePeriod and a Money value.
 *
 * @author Luyanda
 * @date 30/08/2025
 */
public class TariffTable {
    private ParkingTariff[] parkingTariffs;
    private int nextFree;

    public TariffTable(int maxSize) {
        this.parkingTariffs = new ParkingTariff[maxSize];
        this.nextFree = 0;
    }

    public void addTariff(TimePeriod period, Money cost) {
        if (nextFree > 0) {
            ParkingTariff prev = parkingTariffs[nextFree - 1];
            if (!prev.isDirectlyFollowedBy(period)) {
                throw new IllegalArgumentException("Tariff periods must be adjacent.");
            }
        }
        parkingTariffs[nextFree] = new ParkingTariff(period, cost);
        nextFree++;
    }

    public Money getTariff(Duration d) {
        for (int i = 0; i < nextFree; i++) {
            if (parkingTariffs[i].containsDuration(d)) {
                return parkingTariffs[i].getCost();
            }
        }
        return null;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < nextFree; i++) {
            sb.append(parkingTariffs[i].toString());
            if (i < nextFree - 1) sb.append("\n");
        }
        return sb.toString();
    }
}