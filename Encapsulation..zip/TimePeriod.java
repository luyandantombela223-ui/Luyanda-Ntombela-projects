//TimePeriod represents a Duration range [lowerBound .. upperBound).
//Inclusive lower bound, exclusive upper bound.
//Luyanda Ntombela
//30/08/2025

public class TimePeriod {

    private final Duration lowerBound;
    private final Duration upperBound;

    public TimePeriod(Duration lowerBound, Duration upperBound) {
        if (lowerBound.compareTo(upperBound) >= 0) {
            throw new IllegalArgumentException("Lower bound must be less than upper bound.");
        }
        this.lowerBound = lowerBound;
        this.upperBound = upperBound;
    }

    public Duration lowerBound() {
        return this.lowerBound;
    }

    public Duration upperBound() {
        return this.upperBound;
    }

    public boolean includes(Duration duration) {
        return (duration.compareTo(lowerBound) >= 0 && duration.compareTo(upperBound) < 0);
    }

    public boolean precedes(TimePeriod other) {
        // Returns true if this TimePeriod ends before or exactly when the other starts
        return this.upperBound.compareTo(other.lowerBound) <= 0;
    }

    public boolean adjacent(TimePeriod other) {
        return this.upperBound.equals(other.lowerBound) || this.lowerBound.equals(other.upperBound);
    }

    public String toString() {
        return "[" + Duration.format(lowerBound, "minute") + " .. " +
                     Duration.format(upperBound, "minute") + "]";
    }
}
