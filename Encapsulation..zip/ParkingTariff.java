//ParkingTariff represents a tariff for a given TimePeriod.
//Luyanda Ntombela
//30/08/2025
//NTMLUY004

public class ParkingTariff {
    private Money cost;
    private TimePeriod timePeriod;

    // default constructor
    public ParkingTariff() {}

    // full constructor
    public ParkingTariff(TimePeriod timePeriod, Money cost) {
        this.timePeriod = timePeriod;
        this.cost = cost;
    }

    public boolean containsDuration(Duration d) {
        return timePeriod.includes(d);
    }

    public Money getCost() {
        return cost;
    }

    public TimePeriod getTimePeriod() {
        return timePeriod;
    }

    public boolean isDirectlyFollowedBy(TimePeriod other) {
        return timePeriod.adjacent(other);
    }

    public void setMoney(Money cost) {
        this.cost = cost;
    }

    public void setTimePeriod(TimePeriod timePeriod) {
        this.timePeriod = timePeriod;
    }

    @Override
    public String toString() {
        return timePeriod.toString() + " : " + cost.toString();
    }
}
