// A code to create a CowsAndBulls game
// Luyanda Ntombela
// NTMLUY004
// 14 September 2025

public class CowsAndBulls {
    public final static int NUM_DIGITS = 4;
    public final static int MAX_VALUE = 9876;
    public final static int MIN_VALUE = 1234;
    public final static int MAX_GUESSES = 10;

    private int secretNumber;
    private int guessesRemaining;
    private boolean gameWon;

    // Constructor: use NumberPicker with seed
    public CowsAndBulls(int seed) {
        guessesRemaining = MAX_GUESSES;
        gameWon = false;

        // NumberPicker is provided in additional resources
        NumberPicker picker = new NumberPicker(seed, 1, 9); // digits 1-9 only
        int number = 0;
        for (int i = 0; i < NUM_DIGITS; i++) {
            int digit = picker.nextInt();
            number = number * 10 + digit;
        }
        secretNumber = number;
    }

    // Return guesses left
    public int guessesRemaining() {
        return guessesRemaining;
    }

    // Process a guess and return a Result
    public Result guess(int guessNumber) {
        guessesRemaining--;

        int bulls = NumberUtils.countMatches(secretNumber, guessNumber);
        int cows = NumberUtils.countIntersect(secretNumber, guessNumber) - bulls;

        if (bulls == NUM_DIGITS) {
            gameWon = true;
        }

        // FIXED: Result expects (cows, bulls), not (bulls, cows)
        return new Result(cows, bulls);
    }

    // End the game and reveal secret
    public int giveUp() {
        guessesRemaining = 0;
        return secretNumber;
    }

    // True if game is over
    public boolean gameOver() {
        return gameWon || guessesRemaining <= 0;
    }
}
