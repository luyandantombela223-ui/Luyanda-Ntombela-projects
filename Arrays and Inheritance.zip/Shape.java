// A code to implement the class of Shape
// Luyanda Ntombela
// NTMLUY004
// 14 September 2025

public class Shape {
    protected String name;
    protected String colour;

    // Normal constructor
    public Shape(String name, String colour) {
        this.name = name;
        this.colour = colour;
    }

    // Copy constructor
    public Shape(Shape other) {
        this.name = other.name;
        this.colour = other.colour;
    }

    @Override
    public String toString() {
        return name + " " + colour;
    }
}
