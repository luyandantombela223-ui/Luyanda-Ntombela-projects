// A code to inherit shape class from circle
// Luyanda Ntombela
// NTMLUY004
// 14 Sptember 2025

public class Circle extends Shape {
    private double radius;

    // Normal constructor
    public Circle(String name, String colour, double radius) {
        super(name, colour);
        this.radius = radius;
    }

    // Copy constructor
    public Circle(Circle other) {
        super(other.name, other.colour);
        this.radius = other.radius;
    }

    @Override
    public String toString() {
        return name + " " + colour + " Radius " + radius;
    }
}
