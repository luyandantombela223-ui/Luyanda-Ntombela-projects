// A code for inheritance and arrays(Number utils)
// Luyanda Ntombela 
// NTMLUY004
// 13 September 2025

class NumberUtils{


     private NumberUtils() {} 
     
 public static int[] toArray(int number) {
       String numberstring = String.valueOf(number);
       int[] A = new int[numberstring.length()];
       
       for (int i = 0 ; i < numberstring.length();i++){
            A[i] = numberstring.charAt(i)-'0';
            }
  return A ;      
  }

public static int countMatches(int numberA, int numberB){
     int count = 0 ;
     int[] A = toArray(numberA);
     int[] B = toArray(numberB);
     
     String numberstring = String.valueOf(numberA);
     for (int i = 0 ; i < numberstring.length();i++){
          if (A[i]==B[i]){
            count++ ;
            continue;
             }
          else
             continue;
           
           }
     return count ;
      }
public static int countIntersect(int numberA, int numberB){
    int count = 0;
    int[] A = toArray(numberA);
    int[] B = toArray(numberB);
    
    for (int j : A){
       for (int k : B){
           if (k == j){
              count++;
                 }
          }
        }
   return count;    
}
}  