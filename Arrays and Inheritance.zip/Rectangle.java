// Name: Luyanda Ntombela
// Student Number: NTMLUY004
// CSC1016S Assignment 7 - Question 2

/**
 * Rectangle class - represents a rectangle vector object
 * Draws a rectangle with specified width and height
 */
public class Rectangle extends VectorObject {
    private int xLength;
    private int yLength;
    
    /**
     * Constructor for Rectangle
     * @param anId - unique identifier for the rectangle
     * @param ax - x coordinate of top-left corner
     * @param ay - y coordinate of top-left corner
     * @param xLen - width of the rectangle
     * @param yLen - height of the rectangle
     */
    public Rectangle(int anId, int ax, int ay, int xLen, int yLen) {
        super(anId, ax, ay);
        this.xLength = xLen;
        this.yLength = yLen;
    }
    
    /**
     * Draws the rectangle on the character matrix
     * @param matrix - 2D character array representing the canvas
     */
    @Override
    public void draw(char[][] matrix) {
        // Draw top and bottom horizontal lines
        for (int i = 0; i < xLength; i++) {
            int xPos = x + i;
            if (xPos >= 0 && xPos < matrix[0].length) {
                // Top line
                if (y >= 0 && y < matrix.length) {
                    matrix[y][xPos] = '*';
                }
                // Bottom line
                int bottomY = y + yLength - 1;
                if (bottomY >= 0 && bottomY < matrix.length) {
                    matrix[bottomY][xPos] = '*';
                }
            }
        }
        
        // Draw left and right vertical lines
        for (int i = 0; i < yLength; i++) {
            int yPos = y + i;
            if (yPos >= 0 && yPos < matrix.length) {
                // Left line
                if (x >= 0 && x < matrix[0].length) {
                    matrix[yPos][x] = '*';
                }
                // Right line
                int rightX = x + xLength - 1;
                if (rightX >= 0 && rightX < matrix[0].length) {
                    matrix[yPos][rightX] = '*';
                }
            }
        }
    }
}