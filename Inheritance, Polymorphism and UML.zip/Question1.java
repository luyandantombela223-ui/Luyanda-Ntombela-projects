// Name: Luyanda Ntombela
// Student Number: NTMLUY004
// CSC1016S Assignment 7 - Question 1

import java.util.Scanner;
import java.util.ArrayList;

/**
 * Question1 - Main program for managing computer parts
 * Allows adding, deleting, and listing computer boxes, screens, and accessories
 */
public class Question1 {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Part> parts = new ArrayList<>();
        
        System.out.println("Welcome to Great International Technology");
        
        while (true) {
            System.out.println("MENU: add (B)ox, add (S)creen, add (A)ccessories, (D)elete, (L)ist, (Q)uit");
            String choice = scanner.nextLine().toLowerCase();
            
            if (choice.equals("b")) {
                // Add Box
                System.out.println("Enter the serial number");
                String serialNumber = scanner.nextLine();
                
                System.out.println("Enter the manufacturer");
                String manufacturer = scanner.nextLine();
                
                System.out.println("Enter the colour");
                String colour = scanner.nextLine();
                
                System.out.println("Enter the amount of memory (MB)");
                int memory = Integer.parseInt(scanner.nextLine());
                
                parts.add(new Box(serialNumber, manufacturer, colour, memory));
                System.out.println("Done");
                
            } else if (choice.equals("s")) {
                // Add Screen
                System.out.println("Enter the serial number");
                String serialNumber = scanner.nextLine();
                
                System.out.println("Enter the manufacturer");
                String manufacturer = scanner.nextLine();
                
                System.out.println("Enter the colour");
                String colour = scanner.nextLine();
                
                System.out.println("Enter the screen size in inches");
                int size = Integer.parseInt(scanner.nextLine());
                
                parts.add(new Screen(serialNumber, manufacturer, colour, size));
                System.out.println("Done");
                
            } else if (choice.equals("a")) {
                // Add Accessory
                System.out.println("Enter the serial number");
                String serialNumber = scanner.nextLine();
                
                System.out.println("Enter the manufacturer");
                String manufacturer = scanner.nextLine();
                
                System.out.println("Enter the colour");
                String colour = scanner.nextLine();
                
                parts.add(new Accessory(serialNumber, manufacturer, colour));
                System.out.println("Done");
                
            } else if (choice.equals("d")) {
                // Delete part
                System.out.println("Enter the serial number");
                String serialNumber = scanner.nextLine();
                
                boolean found = false;
                for (int i = 0; i < parts.size(); i++) {
                    if (parts.get(i).getSerialNumber().equals(serialNumber)) {
                        parts.remove(i);
                        found = true;
                        break;
                    }
                }
                
                if (found) {
                    System.out.println("Done");
                } else {
                    System.out.println("Not found");
                }
                
            } else if (choice.equals("l")) {
                // List all parts
                for (Part part : parts) {
                    System.out.println(part);
                }
                System.out.println("Done");
                
            } else if (choice.equals("q")) {
                // Quit
                break;
            }
        }
        
        scanner.close();
    }
}