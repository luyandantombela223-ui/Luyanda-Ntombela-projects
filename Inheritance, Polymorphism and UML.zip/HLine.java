// Name: Luyanda Ntombela
// Student Number: NTMLUY004
// CSC1016S Assignment 7 - Question 2

/**
 * HLine class - represents a horizontal line vector object
 * Draws a horizontal line with specified length
 */
public class HLine extends VectorObject {
    private int length;
    
    /**
     * Constructor for HLine
     * @param anId - unique identifier for the line
     * @param ax - x coordinate of starting point
     * @param ay - y coordinate of starting point
     * @param len - length of the horizontal line
     */
    public HLine(int anId, int ax, int ay, int len) {
        super(anId, ax, ay);
        this.length = len;
    }
    
    /**
     * Draws the horizontal line on the character matrix
     * @param matrix - 2D character array representing the canvas
     */
    @Override
    public void draw(char[][] matrix) {
        // Draw horizontal line from (x, y) extending right by length
        for (int i = 0; i < length; i++) {
            int xPos = x + i;
            if (xPos >= 0 && xPos < matrix[0].length && y >= 0 && y < matrix.length) {
                matrix[y][xPos] = '*';
            }
        }
    }
}