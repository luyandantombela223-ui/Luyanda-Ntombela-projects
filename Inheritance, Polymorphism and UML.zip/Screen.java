// Name: Luyanda Ntombela
// Student Number: NTMLUY004
// CSC1016S Assignment 7 - Question 1

/**
 * Screen - Represents a computer screen with size
 * Extends Part class
 */
public class Screen extends Part {
    private int size;
    
    /**
     * Constructor for Screen
     * @param serialNumber - unique identifier
     * @param manufacturer - manufacturer name
     * @param colour - colour of the screen
     * @param size - screen size in inches
     */
    public Screen(String serialNumber, String manufacturer, String colour, int size) {
        super(serialNumber, manufacturer, colour);
        this.size = size;
    }
    
    /**
     * Returns string representation of the screen
     * @return formatted string with screen details
     */
    @Override
    public String toString() {
        return "Screen: " + serialNumber + ", " + manufacturer + ", " + colour + ", " + size;
    }
}