// Name: Luyanda Ntombela
// Student Number: NTMLUY004
// CSC1016S Assignment 7 - Question 2

/**
 * Question2 - Main class for vector graphics program
 * Reads commands from a file and renders graphical objects
 */
public class Question2 {
    
    /**
     * Main method
     * @param args - command line arguments (expects filename as first argument)
     */
    public static void main(String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java Question2 <filename>");
            return;
        }
        
        // Create a 20x20 canvas with room for up to 100 objects
        VectorGraphics vg = new VectorGraphics(20, 20, 100);
        
        // Run the program with the specified file
        vg.run(args[0]);
    }
}