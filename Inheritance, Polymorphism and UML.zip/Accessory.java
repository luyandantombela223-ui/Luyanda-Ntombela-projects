// Name: Luyanda Ntombela
// Student Number: NTMLUY004
// CSC1016S Assignment 7 - Question 1

/**
 * Accessory - Represents a computer accessory
 * Extends Part class
 */
public class Accessory extends Part {
    
    /**
     * Constructor for Accessory
     * @param serialNumber - unique identifier
     * @param manufacturer - manufacturer name
     * @param colour - colour of the accessory
     */
    public Accessory(String serialNumber, String manufacturer, String colour) {
        super(serialNumber, manufacturer, colour);
    }
    
    /**
     * Returns string representation of the accessory
     * @return formatted string with accessory details
     */
    @Override
    public String toString() {
        return "Accessories: " + serialNumber + ", " + manufacturer + ", " + colour;
    }
}