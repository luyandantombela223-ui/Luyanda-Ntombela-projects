// Name: Luyanda Ntombela
// Student Number: NTMLUY004
// CSC1016S Assignment 7 - Question 2

/**
 * PtLine class - represents a point-to-point line vector object
 * Draws a line from one point to another using Bresenham's algorithm
 */
public class PtLine extends VectorObject {
    private int x1;
    private int y1;
    
    /**
     * Constructor for PtLine
     * @param anId - unique identifier for the line
     * @param ax - x coordinate of starting point
     * @param ay - y coordinate of starting point
     * @param bx - x coordinate of ending point
     * @param by - y coordinate of ending point
     */
    public PtLine(int anId, int ax, int ay, int bx, int by) {
        super(anId, ax, ay);
        this.x1 = bx;
        this.y1 = by;
    }
    
    /**
     * Draws the line on the character matrix using Bresenham's algorithm
     * @param matrix - 2D character array representing the canvas
     */
    @Override
    public void draw(char[][] matrix) {
        int x0 = x;
        int y0 = y;
        
        // Bresenham's line drawing algorithm
        boolean steep = Math.abs(y1 - y0) > Math.abs(x1 - x0);
        
        if (steep) {
            // Swap x and y
            int temp = x0;
            x0 = y0;
            y0 = temp;
            
            temp = x1;
            x1 = y1;
            y1 = temp;
        }
        
        if (x0 > x1) {
            // Swap start and end points
            int temp = x0;
            x0 = x1;
            x1 = temp;
            
            temp = y0;
            y0 = y1;
            y1 = temp;
        }
        
        int ys = (y0 < y1) ? 1 : -1;
        double m = Math.abs(y1 - y0) / (double)(x1 - x0);
        int yPos = y0;
        double error = 0;
        
        for (int xPos = x0; xPos <= x1; xPos++) {
            // Plot the point, swapping back if steep
            int plotX = steep ? yPos : xPos;
            int plotY = steep ? xPos : yPos;
            
            if (plotX >= 0 && plotX < matrix[0].length && plotY >= 0 && plotY < matrix.length) {
                matrix[plotY][plotX] = '*';
            }
            
            error += m;
            if (error > 0.5) {
                yPos += ys;
                error -= 1;
            }
        }
    }
}