// Name: Luyanda Ntombela
// Student Number: NTMLUY004
// CSC1016S Assignment 7 - Question 1

/**
 * Box - Represents a computer box with memory
 * Extends Part class
 */
public class Box extends Part {
    private int memory;
    
    /**
     * Constructor for Box
     * @param serialNumber - unique identifier
     * @param manufacturer - manufacturer name
     * @param colour - colour of the box
     * @param memory - amount of memory in MB
     */
    public Box(String serialNumber, String manufacturer, String colour, int memory) {
        super(serialNumber, manufacturer, colour);
        this.memory = memory;
    }
    
    /**
     * Returns string representation of the box
     * @return formatted string with box details
     */
    @Override
    public String toString() {
        return "Box: " + serialNumber + ", " + manufacturer + ", " + colour + ", " + memory;
    }
}