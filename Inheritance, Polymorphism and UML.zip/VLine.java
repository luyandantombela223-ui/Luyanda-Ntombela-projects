// Name: Luyanda Ntombela
// Student Number: NTMLUY004
// CSC1016S Assignment 7 - Question 2

/**
 * VLine class - represents a vertical line vector object
 * Draws a vertical line with specified length
 */
public class VLine extends VectorObject {
    private int length;
    
    /**
     * Constructor for VLine
     * @param anId - unique identifier for the line
     * @param ax - x coordinate of starting point
     * @param ay - y coordinate of starting point
     * @param len - length of the vertical line
     */
    public VLine(int anId, int ax, int ay, int len) {
        super(anId, ax, ay);
        this.length = len;
    }
    
    /**
     * Draws the vertical line on the character matrix
     * @param matrix - 2D character array representing the canvas
     */
    @Override
    public void draw(char[][] matrix) {
        // Draw vertical line from (x, y) extending down by length
        for (int i = 0; i < length; i++) {
            int yPos = y + i;
            if (yPos >= 0 && yPos < matrix.length && x >= 0 && x < matrix[0].length) {
                matrix[yPos][x] = '*';
            }
        }
    }
}